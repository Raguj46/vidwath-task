package com.example.viddemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
