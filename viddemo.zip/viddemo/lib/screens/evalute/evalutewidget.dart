import 'package:flutter/material.dart';
class EvaluteWidget extends StatefulWidget {
  const EvaluteWidget({Key? key}) : super(key: key);

  @override
  State<EvaluteWidget> createState() => _EvaluteWidgetState();
}

class _EvaluteWidgetState extends State<EvaluteWidget> {
  List<Color> Colorslist=[
    Colors.orange.shade100,
    Colors.yellow.shade100,
    Colors.blue.shade100,
    Colors.yellow.shade100,
    Colors.orange.shade100,
    Colors.green.shade100,
    Colors.orange.shade100,
    Colors.grey.shade100,
    Colors.purple.shade100,
    Colors.green.shade100,
  ];
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(height: 18,),
        Row(mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("You Know You Can. You Got This!",style: TextStyle(fontSize: 16),),
          ],
        ),
          const SizedBox(height: 12,),
          Container(
            height: MediaQuery.of(context).size.height-185,
            child: ListView.builder(
              itemCount: 10,
                itemBuilder: (BuildContext context,index){
              return Padding(
                padding: EdgeInsets.only(left: 8,right: 22,bottom: 8,top: 12),
                child: Container(
                  child: Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(topLeft:Radius.circular(8) ,bottomLeft: Radius.circular(8)),
                          color: Colorslist[index],
                        ),

                        child: Padding(
                          padding: const EdgeInsets.only(right: 8.0,),
                          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                image: DecorationImage(
                                    image: AssetImage("assets/rose.jpg"),
                                    fit: BoxFit.cover),
                              ),
                              height: 70,
                              width: 80,

                            ),
                              Column(
                                children: [
                                  Text("15 Chapter",style: TextStyle(fontSize: 16,color: Colors.black,fontWeight: FontWeight.bold),),
                                  const SizedBox(height: 8,),
                                  Text("NCERT SOLUTIONS/QUESTION BANK/WORKSHEET/..",style: TextStyle(fontSize: 10),)
                                ],
                              )
                          ],),
                        ),
                      ),
                      Row(children: [
                        Text("Mathematics",)
                      ],)
                    ],
                  ),
                ),
              );
            }),
          )
        ],
      ),
    );
  }
}
