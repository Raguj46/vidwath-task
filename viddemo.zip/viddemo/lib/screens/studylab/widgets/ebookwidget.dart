import 'package:flutter/material.dart';
class EbookWidget extends StatefulWidget {
  const EbookWidget({Key? key}) : super(key: key);

  @override
  State<EbookWidget> createState() => _EbookWidgetState();
}

class _EbookWidgetState extends State<EbookWidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8.0,right: 8),
      child: Column(
        children: [
      Container(
      height: MediaQuery.of(context).size.height-270,
        child: GridView.builder(
        scrollDirection: Axis.vertical,
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 200,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.89,

           ),
    itemCount: 7,
    itemBuilder: (BuildContext context,index){
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 12,left: 12),
          child: Column(
            children: [
              Container(
                height: 160,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15)
                ),
                child: Image.asset("assets/rose.jpg",fit: BoxFit.fill,),
              ),
            ],
          ),
        ),
        const SizedBox(height: 4,),
        Padding(
          padding: const EdgeInsets.only(left: 12.0,right: 14),
          child: Container(height: 3,color: Colors.grey.shade400,),
        )
      ],
    );})),
        ],
      ),
    );
  }
}
