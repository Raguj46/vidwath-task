import 'package:flutter/material.dart';
class TutorialVideoWidget extends StatefulWidget {
  const TutorialVideoWidget({Key? key}) : super(key: key);

  @override
  State<TutorialVideoWidget> createState() => _TutorialVideoWidgetState();
}

class _TutorialVideoWidgetState extends State<TutorialVideoWidget> {
  
  List<Color> Colorslist=[
    const Color.fromRGBO(255, 83, 71, 1),
    const Color.fromRGBO(90, 77, 183, 1),
    const Color.fromRGBO(65, 173, 199, 1),
    const Color.fromRGBO(255, 138, 65, 1),
    const Color.fromRGBO(91, 174, 252, 1),
    const Color.fromRGBO(245, 237, 137, 1),
    const Color.fromRGBO(234, 90, 97, 1),
    const Color.fromRGBO(245, 237, 137, 1),
    const Color.fromRGBO(234, 90, 97, 1),
    const Color.fromRGBO(91, 174, 252, 1),
  ];
  
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8.0,right: 8),
      child: Column(
        children: [
          const SizedBox(height: 8,),
          Padding(
            padding: const EdgeInsets.only(left: 2.0,right: 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text("Mathematics",style: TextStyle(fontSize: 16),),
                Text("View All",style: TextStyle(fontSize: 12,color: Colors.blue),),
              ],
            ),
          ),
          const SizedBox(height: 6,),
          Container(
            height: 120,
           child: GridView.builder(
               scrollDirection: Axis.horizontal,
               gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                       maxCrossAxisExtent: 200,
                       crossAxisSpacing: 6,
                       mainAxisSpacing: 6,
                 childAspectRatio: 0.8,

                   ),
               itemCount: 10,
               itemBuilder: (BuildContext context,index){
                 return Container(
                   decoration: BoxDecoration(
                     borderRadius: BorderRadius.circular(8),
                     color: Colorslist[index],
                   ),
                   child: Column(
                     children: [
                       const SizedBox(height: 8,),
                       Padding(
                         padding: const EdgeInsets.only(right: 8.0,bottom: 8,top: 8,left: 4),
                         child: Column(
                           children: [
                             Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                               children: [
                                 Padding(
                                   padding: const EdgeInsets.only(left: 6.0),
                                   child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                                     children: [
                                       const Text('Harishma',style: TextStyle(fontSize: 10,fontWeight: FontWeight.bold,color: Colors.white),),
                                        const SizedBox(height: 2,),
                                        Container(height: 1,width: 66,color: Colors.white,),
                                       const SizedBox(
                                         height: 4,
                                       ),
                                       const Text("Mathematics",style: TextStyle(fontSize: 10,color: Colors.white),)
                                     ],
                                   ),
                                 ),
                                 Container(
                                   height: 50,
                                   width: 50,
                                   decoration: BoxDecoration(
                                     color: Colors.grey,
                                     borderRadius: BorderRadius.circular(50),
                                     image: DecorationImage(
                                         image: AssetImage("assets/rose.jpg"),
                                         fit: BoxFit.cover),
                                   ),
                                 )
                               ],
                             ),

                           ],
                         ),
                       ),
                       Container(
                         height:46,
                         width: MediaQuery.of(context).size.width,
                         decoration: const BoxDecoration(
                           borderRadius: BorderRadius.only(bottomLeft: Radius.circular(8),bottomRight: Radius.circular(8)),
                           color: Color.fromRGBO(239, 233, 233, 1),
                         ),
                         child: Column(
                           children: [
                             const SizedBox(height: 2,),
                             const Text("Triangles",style: TextStyle(fontSize: 10,fontWeight: FontWeight.bold),),
                             const SizedBox(height: 2,),
                             Text("Similar Futues Ex 6.1",style: TextStyle(fontSize: 8,color: Colors.grey.shade800),),
                             const SizedBox(height: 6,),
                             Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                               children: [
                                 Container(
                                   decoration: const BoxDecoration(
                                     borderRadius: BorderRadius.only(topRight: Radius.circular(8) ,bottomLeft:Radius.circular(8) ,bottomRight: Radius.circular(8)),
                                     color: Colors.red
                                   ),
                                   child: const Padding(
                                     padding: EdgeInsets.only(left: 12,right: 12,top: 3,bottom: 3),
                                     child: Text("Subscribe",style: TextStyle(fontSize: 8,color: Colors.white),),
                                   ),
                                 ),
                                 Container(
                                   decoration: const BoxDecoration(
                                       borderRadius: BorderRadius.only(topLeft: Radius.circular(8) ,bottomLeft:Radius.circular(8) ,bottomRight: Radius.circular(8)),
                                       color: Colors.black
                                   ),
                                   child: const Padding(
                                     padding: EdgeInsets.only(left: 8,right: 8,top: 3,bottom: 3),
                                     child: Text("19 MINS",style: TextStyle(fontSize: 8,color: Colors.white),),
                                   ),
                                 ),
                               ],
                             )
                           ],
                         ),

                       )
                     ],

                   ),
                 );
           })


            //  (
            //   scrollDirection: Axis.horizontal,
            //   gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
            //       maxCrossAxisExtent: 200,
            //       childAspectRatio: 3 / 2,
            //       crossAxisSpacing: 20,
            //       mainAxisSpacing: 20
            //   ),
            //   children: [
            //     // Some widgets
            //   ],
            // ),
          ),
          const SizedBox(height: 18,),
          Padding(
            padding: const EdgeInsets.only(left: 2.0,right: 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text("Maths Questionnaire",style: TextStyle(fontSize: 16),),
                Text("View All",style: TextStyle(fontSize: 12,color: Colors.blue),),
              ],
            ),
          ),
          const SizedBox(height: 6,),
          Container(
              height: 120,
              child: GridView.builder(
                  scrollDirection: Axis.horizontal,
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 200,
                    crossAxisSpacing: 6,
                    mainAxisSpacing: 6,
                    childAspectRatio: 0.8,

                  ),
                  itemCount: 10,
                  itemBuilder: (BuildContext context,index){
                    return Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colorslist[index],
                      ),
                      child: Column(
                        children: [
                          const SizedBox(height: 8,),
                          Padding(
                            padding: const EdgeInsets.only(right: 8.0,bottom: 8,top: 8,left: 4),
                            child: Column(
                              children: [
                                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(left: 6.0),
                                      child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          const Text('Harishma',style: TextStyle(fontSize: 10,fontWeight: FontWeight.bold,color: Colors.white),),
                                          const SizedBox(height: 2,),
                                          Container(height: 1,width: 66,color: Colors.white,),
                                          const SizedBox(
                                            height: 4,
                                          ),
                                          const Text("Mathematics",style: TextStyle(fontSize: 10,color: Colors.white),)
                                        ],
                                      ),
                                    ),
                                    Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                          color: Colors.grey,
                                          borderRadius: BorderRadius.circular(50),
                                        image: const DecorationImage(
                                            image: AssetImage("assets/rose.jpg"),
                                            fit: BoxFit.cover),
                                      ),
                                    )
                                  ],
                                ),

                              ],
                            ),
                          ),
                          Container(
                            height:46,
                            width: MediaQuery.of(context).size.width,
                            decoration: const BoxDecoration(
                              borderRadius: BorderRadius.only(bottomLeft: Radius.circular(8),bottomRight: Radius.circular(8)),
                              color: Color.fromRGBO(239, 233, 233, 1),
                            ),
                            child: Column(
                              children: [
                                const SizedBox(height: 2,),
                                const Text("Triangles",style: TextStyle(fontSize: 10,fontWeight: FontWeight.bold),),
                                const SizedBox(height: 2,),
                                Text("Similar Futues Ex 6.1",style: TextStyle(fontSize: 8,color: Colors.grey.shade800),),
                                const SizedBox(height: 6,),
                                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.only(topRight: Radius.circular(8) ,bottomLeft:Radius.circular(8) ,bottomRight: Radius.circular(8)),
                                          color: Colors.red
                                      ),
                                      child: const Padding(
                                        padding: EdgeInsets.only(left: 12,right: 12,top: 3,bottom: 3),
                                        child: Text("Subscribe",style: TextStyle(fontSize: 8,color: Colors.white),),
                                      ),
                                    ),
                                    Container(
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.only(topLeft: Radius.circular(8) ,bottomLeft:Radius.circular(8) ,bottomRight: Radius.circular(8)),
                                          color: Colors.black
                                      ),
                                      child: const Padding(
                                        padding: EdgeInsets.only(left: 8,right: 8,top: 3,bottom: 3),
                                        child: Text("19 MINS",style: TextStyle(fontSize: 8,color: Colors.white),),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),

                          )
                        ],

                      ),
                    );
                  })


            //  (
            //   scrollDirection: Axis.horizontal,
            //   gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
            //       maxCrossAxisExtent: 200,
            //       childAspectRatio: 3 / 2,
            //       crossAxisSpacing: 20,
            //       mainAxisSpacing: 20
            //   ),
            //   children: [
            //     // Some widgets
            //   ],
            // ),
          ),
          const SizedBox(height: 18,),
          Padding(
            padding: const EdgeInsets.only(left: 2.0,right: 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text("Science",style: TextStyle(fontSize: 16),),
                Text("View All",style: TextStyle(fontSize: 12,color: Colors.blue),),
              ],
            ),
          ),
          const SizedBox(height: 6,),
          Container(
              height: 120,
              child: GridView.builder(
                  scrollDirection: Axis.horizontal,
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 200,
                    crossAxisSpacing: 6,
                    mainAxisSpacing: 6,
                    childAspectRatio: 0.8,

                  ),
                  itemCount: 10,
                  itemBuilder: (BuildContext context,index){
                    return Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colorslist[index],
                      ),
                      child: Column(
                        children: [
                          const SizedBox(height: 8,),
                          Padding(
                            padding: const EdgeInsets.only(right: 8.0,bottom: 8,top: 8,left: 4),
                            child: Column(
                              children: [
                                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(left: 6.0),
                                      child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          const Text('Harishma',style: TextStyle(fontSize: 10,fontWeight: FontWeight.bold,color: Colors.white),),
                                          const SizedBox(height: 2,),
                                          Container(height: 1,width: 66,color: Colors.white,),
                                          const SizedBox(
                                            height: 4,
                                          ),
                                          const Text("Mathematics",style: TextStyle(fontSize: 10,color: Colors.white),)
                                        ],
                                      ),
                                    ),
                                    Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                          color: Colors.grey,
                                          borderRadius: BorderRadius.circular(50),
                                        image: DecorationImage(
                                            image: AssetImage("assets/rose.jpg"),
                                            fit: BoxFit.cover),
                                      ),
                                    )
                                  ],
                                ),

                              ],
                            ),
                          ),
                          Container(
                            height:46,
                            width: MediaQuery.of(context).size.width,
                            decoration: const BoxDecoration(
                              borderRadius: BorderRadius.only(bottomLeft: Radius.circular(8),bottomRight: Radius.circular(8)),
                              color: Color.fromRGBO(239, 233, 233, 1),
                            ),
                            child: Column(
                              children: [
                                const SizedBox(height: 2,),
                                const Text("Triangles",style: TextStyle(fontSize: 10,fontWeight: FontWeight.bold),),
                                const SizedBox(height: 2,),
                                Text("Similar Futues Ex 6.1",style: TextStyle(fontSize: 8,color: Colors.grey.shade800),),
                                const SizedBox(height: 6,),
                                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.only(topRight: Radius.circular(8) ,bottomLeft:Radius.circular(8) ,bottomRight: Radius.circular(8)),
                                          color: Colors.red
                                      ),
                                      child: const Padding(
                                        padding: EdgeInsets.only(left: 12,right: 12,top: 3,bottom: 3),
                                        child: Text("Subscribe",style: TextStyle(fontSize: 8,color: Colors.white),),
                                      ),
                                    ),
                                    Container(
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.only(topLeft: Radius.circular(8) ,bottomLeft:Radius.circular(8) ,bottomRight: Radius.circular(8)),
                                          color: Colors.black
                                      ),
                                      child: const Padding(
                                        padding: EdgeInsets.only(left: 8,right: 8,top: 3,bottom: 3),
                                        child: Text("19 MINS",style: TextStyle(fontSize: 8,color: Colors.white),),
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),

                          )
                        ],

                      ),
                    );
                  })


            //  (
            //   scrollDirection: Axis.horizontal,
            //   gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
            //       maxCrossAxisExtent: 200,
            //       childAspectRatio: 3 / 2,
            //       crossAxisSpacing: 20,
            //       mainAxisSpacing: 20
            //   ),
            //   children: [
            //     // Some widgets
            //   ],
            // ),
          ),
        ],
      ),
    );
  }
}
