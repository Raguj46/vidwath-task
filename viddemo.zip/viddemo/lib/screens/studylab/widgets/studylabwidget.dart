import 'package:flutter/material.dart';
import 'package:viddemo/screens/studylab/widgets/tutorialvideowidget.dart';

import 'ebookwidget.dart';
class StudylabWidget extends StatefulWidget {
  const StudylabWidget({Key? key}) : super(key: key);

  @override
  State<StudylabWidget> createState() => _StudylabWidgetState();
}

class _StudylabWidgetState extends State<StudylabWidget> with SingleTickerProviderStateMixin{
  late TabController _tabController;
  @override
  void initState() {
    _tabController = TabController(length: 2, vsync: this);
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          const SizedBox(height: 28,),
          const Text("Learning Made Easy & Fun",style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold),),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.only(left: 12.0,right: 12),
            child: TabBar(
              labelPadding: EdgeInsets.all(4),
              indicatorColor: Colors.orange,
              controller: _tabController,
              tabs:  <Widget>[
                Padding(
                  padding: const EdgeInsets.only(right: 4.0),
                  child: Container(
                    height: 34,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      color: Color.fromRGBO(237, 237, 237, 1),
                    ),

                      child:  Center(child: Text("Tutorial Video",style: TextStyle(fontSize: 16,color: Colors.grey.shade700),))),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 4.0),
                  child: Container(
                      height: 34,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color:  Color.fromRGBO(237, 237, 237, 1),
                      ),

                      child:  Center(child: Text("e-Books",style: TextStyle(fontSize: 16,color: Colors.grey.shade700),))),
                ),

              ],
            ),
          ),
          const SizedBox(height: 8,),
          SizedBox(
            height: MediaQuery.of(context).size.height-252,
            child: TabBarView(
              controller: _tabController,
              children: [
                TutorialVideoWidget(),
                EbookWidget()
              ],
            ),
          ),
        ],
      ),
    );
  }
}
