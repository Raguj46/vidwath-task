//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<screen_capture_event/ScreenCaptureEventPlugin.h>)
#import <screen_capture_event/ScreenCaptureEventPlugin.h>
#else
@import screen_capture_event;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [ScreenCaptureEventPlugin registerWithRegistrar:[registry registrarForPlugin:@"ScreenCaptureEventPlugin"]];
}

@end
